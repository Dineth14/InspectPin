# Project status — 2026-11-03

## Integrated software platform — implemented and simulator-verified

The repository now includes a persistent product API, responsive React
dashboard, expanded Flutter client and Windows simulator. The final live mock
scenario passed pairing, heartbeat, PHOTO/JPEG, inspection analysis, contextual
assistant and ASK/WAV through mock STT/LLM/TTS. Mock results were labelled.

Current checks: **146 Python tests passed**, Ruff/compileall/pip consistency
passed, **3 web tests passed**, the web production build passed and npm audit
reported zero vulnerabilities. Flutter/Dart and Arduino CLI are not installed,
so no new mobile or firmware build is claimed. See the
[software acceptance report](ACCEPTANCE_REPORT.md).

## Final Rev E power/battery reconciliation — source implemented, fabrication blocked

The final design has exactly two buttons: ASK on D2/GPIO3 and PHOTO on PCF8574
P3. D5/GPIO6 is exclusively the 100 kΩ/100 kΩ/100 nF battery ADC. There is no
dedicated power button. Automatic inactivity selects light sleep; optional deep
sleep may wake from existing ASK or PCF8574 INT on D4/GPIO5 only after physical
validation. MAX17043/MAX17048 are removed from the design.

Implemented artifacts include the conflict report, corrected net-level
schematic specification, connection diagram, BOM, PCB rules, blocked ERC report,
electrical test procedure, PCF8574 manager, reconciled pin profile, automatic
sleep policy, GPIO6 battery monitor, hardware charge-state input, and Flutter
battery model/card with warnings.

Actual software results: eight reconciliation/architecture host tests passed;
the normal bench configuration compiled at **1,113,230 bytes flash / 59,904
bytes static RAM**; the explicit Rev E candidate compiled at **1,135,598 bytes
flash / 60,336 bytes static RAM**. Neither reconciled build was uploaded because
the connected board still has historical bench wiring.

Fabrication remains **blocked**: the actual Rev E KiCad source is absent, KiCad
CLI is unavailable, and no revised ERC, continuity, ADC, standby/back-power,
wake-current or charging-LED measurements exist. See the
[reconciliation report](../hardware/REV_E_RECONCILIATION_REPORT.md) and
[verification procedure](../hardware/REV_E_VERIFICATION_PROCEDURE.md).
Evidence: [Rev E software/build record](evidence/rev-e-reconciliation-2026-11-03.txt).

## Phase 3 — buttons, illumination and command dispatch (software complete; drivers gated)

The current bench mapping is preserved by default: D2/GPIO3 voice and D5/GPIO6
photo. `IP_BUTTON_LAYOUT_FINAL=true` explicitly selects the proposed product
mapping: D2 short voice, D2 long photo, D5 long deliberate sleep. Held-at-boot
buttons remain disarmed, debounce is 40 ms, and simultaneous actions have a
deterministic power/camera/voice priority.

The illumination controller clamps brightness, enforces timeout/low-battery
restrictions, turns off after photo, and reports requested versus actual state.
It remains disabled until a GPIO43 MOSFET driver is verified. Runtime volume
and haptic commands validate bounds. The backend voice router recognizes only
explicit aliases, requires confirmation for sleep/restart, and emits an
allow-listed command; unmatched questions continue to AI.

Actual checks: **134 tests passed in 7.11 s**, Ruff passed, exact XIAO build
passed at **1,094,534 bytes flash / 58,304 bytes static RAM**, and COM7 upload
hashes verified. Board diagnostics showed both released buttons HIGH, legacy
two-button mode active, light/haptic off, volume 100, and truthful offline state.
Wi-Fi prevented a physical spoken-command round trip; driver tests remain pending.
Evidence: [Phase 3 record](evidence/phase3-2026-11-03.txt).

## Phase 2 — power, battery, charging and haptics (software complete; hardware gated)

The safe-default implementation now includes wake-reason/idle/deep/light sleep
logic, peripheral shutdown hooks in the app, a filtered Li-ion estimate with
persisted calibration and hysteresis, explicit charging validity, a host-tested
VBUS decoder policy, and a queued non-blocking haptic scheduler. Power, battery,
decoder, light and haptic hardware remain disabled unless explicitly configured.

Executed results:

- Six host architecture/power contracts passed, including the chemistry curve,
  trimmed filter, hysteresis, charger pulse/full latch, and USB-off reset.
- Exact XIAO build passed at **1,089,606 bytes flash** and **58,160 bytes static RAM**.
- COM7 upload passed with verified hashes.
- The board reported battery invalid and charge `unknown`, `charge_valid=no`,
  `source=unavailable`, exactly matching the absent divider/decoder hardware.
- A manual sleep request was safely refused because wake hardware is not
  validated; the SD card was reinitialized. No deep-sleep/current pass is claimed.

Design records: [power](../hardware/POWER_ARCHITECTURE.md),
[battery divider](../hardware/BATTERY_DIVIDER.md),
[single LED decoder](../hardware/CHARGING_STATUS_DECODER.md), and
[haptic driver](../hardware/HAPTIC_DRIVER.md). Physical current, ADC calibration,
wake cycling, LED timing, charger loading and haptic-driver tests remain pending.
Evidence: [Phase 2 record](evidence/phase2-2026-11-03.txt).

## Phase 1 — firmware architecture (implemented; physical regression partial)

Phase 1 now has a typed command/result taxonomy, centralized dispatcher,
hierarchical top-level/ACTIVE state contract, operation arbiter, NVS settings
interface, and numbered event interface. Serial and current bench buttons use
the same dispatch path. Sleep is rejected unless the active operation is idle;
power management remains disabled by default pending GPIO6 and current tests.

Executed results on 2026-11-03:

- Host architecture contracts: **4 passed in 0.92 s**.
- Exact XIAO ESP32-S3 build: **1,088,610 bytes flash**, **58,128 bytes static
  RAM**, build passed with ESP32 core 3.3.12.
- Upload to the connected ESP32-S3 on COM7 passed; esptool verified every hash.
- Physical serial `STATUS_GET` was accepted through the dispatcher and reported
  `OFFLINE`, heap 258,944 and PSRAM 8,346,312 bytes at that instant.
- Battery query truthfully returned `valid=no` because the unverified battery
  feature is disabled.
- The configured Wi-Fi connection failed during this run, so network voice/photo
  regression is still pending and is not claimed from the successful upload.

Evidence: [Phase 1 board/build record](evidence/phase1-2026-11-03.txt).
Phase 2 must not be called physically complete until wake, current, ADC/divider,
and external driver circuits are measured.

## Phase 0 final-product audit

Phase 0 is complete as a documentation and software-baseline phase. It did not implement Phase 1–10 product features. The repository started clean at commit `8ce2796d47d9af6deec23653b3fe3891787ced8a`. The audit confirms the existing firmware/backend core and the absence of the Flutter app, video writer, provisioning, full power manager, device/media API, single-LED decoder circuit, and final PCB design.

Current executed checks: **110 backend tests passed in 7.21 s**; Ruff, Python byte compilation and dependency consistency passed; mock Waitress voice/registered-image workflows passed; real `qwen2.5vl:3b` read the synthetic fixture's 230 V and 4.2 A values; the XIAO firmware compiled with ESP32 core 3.3.12 at **1,082,582 bytes flash** and **58,064 bytes static RAM**. No board was connected, so no new physical pass is claimed. Flutter was not installed/on PATH.

Phase 0 artifacts:

- [Repository audit](REPOSITORY_AUDIT.md)
- [Feasibility decisions and gates](FEASIBILITY_DECISIONS.md)
- [58-requirement traceability baseline](REQUIREMENTS_TRACEABILITY.md)
- [Pin/electrical conflict matrix](../hardware/PIN_CONFLICT_MATRIX.md)
- [Dated evidence](evidence/phase0-2026-11-03)

The final pin budget remains open because the VBUS-powered charge decoder needs an ESP32 status interface while GPIO43/44 are proposed for illumination/haptics. Phase 1 may define abstractions but must not change physical defaults or enable unverified hardware. Hardware gates for wake, battery calibration, charge indication, drivers, battery-only power, AVI performance, BLE provisioning, and current/reliability remain pending.

**OV3660 profile update:** the firmware now has a centralized, compile-time optimized profile and strict runtime readback. The approved default is 20 MHz XCLK, JPEG, SVGA 800 x 600, quality 12, brightness +1, contrast 0, saturation -2, sharpness +1, de-noise 5, AE level 0, AWB/AEC/AGC/gamma/lens correction enabled, night mode disabled, and official OV3660 vertical flip enabled. The connected sensor passed all 20 configured setter/readback checks and reported raw initialized gain-ceiling status 248; this value is preserved and is not presented as an enum or as the lost manually tuned value. The original CameraWebServer `/status` JSON is still needed to convert provisional slider values into authoritative values.

ESP32 core 3.3.12 compilation passed after this change: 1,082,602 bytes flash and 58,064 bytes static RAM. The firmware was uploaded to COM7 with verified flash hashes. Physical CAM01/CAM02 passed, and one CAM03/CAM04 capture was saved and reopened at 21,276 bytes and 800 x 600. Network receipt was blocked because the laptop was not on the board's configured hotspot, so CAM05–CAM10 remain pending rather than inferred. See [bench evidence](evidence/camera-profile-hardware.txt), [CAMERA_OPTIMIZATION](CAMERA_OPTIMIZATION.md), and [TESTING](TESTING.md#ov3660-profile-acceptance-tests).

**Later bench update:** the models are now installed, two-button firmware has been uploaded to COM7, SD/network checks passed, and actual microphone → Qwen → Piper → board playback completed. The user confirmed audible speech but reported low volume; a local gain adjustment is in progress. Clear real-camera label recognition remains unverified. See [the current bench record](ACTUAL_MODEL_TEST.md) for results, failures and timings. The delivery snapshot below records the earlier state before these hardware tests.

The multimodal source implementation and software verification are complete. **Real Qwen recognition and physical end-to-end acceptance remain pending.** No board was flashed or exercised during this extension. Ollama responds locally, but the requested qwen2.5vl:3b model is absent (qwen3.5:4b is installed); the real image probe returned MODEL_UNAVAILABLE. Follow [MULTIMODAL_GUIDE](MULTIMODAL_GUIDE.md) to download models and use the system, then execute [V01–V10](VISION_TESTING.md).

## Observed verification

| Executed check | Actual result | Evidence |
|---|---|---|
| Full backend suite, Python 3.12.13 | **104 passed in 7.04 s**; existing voice tests retained | [Test log](evidence/multimodal-backend-tests.txt) |
| Ruff / Python byte compilation / pip consistency | All passed; no broken requirements | Commands below |
| Waitress loopback HTTP with mocked AI | Voice upload/poll/WAV; JPEG registration, two visual turns, audio, device isolation and clear passed | [HTTP log](evidence/multimodal-http-check.txt) |
| Final updated firmware compile | ESP32 **3.3.12**, ArduinoJson **7.4.2**; **1,077,194 bytes flash**, **58,032 bytes static RAM** | [Build log](evidence/multimodal-firmware-build.txt) |
| Actual Ollama availability and Qwen probe | Service reachable; qwen3.5:4b installed, requested Qwen2.5-VL absent; **MODEL_UNAVAILABLE**, not recognition success | [Probe log](evidence/multimodal-real-vision-check.txt) |
| Earlier real Piper → Whisper experiment | Exact transcription of synthetic speech; 2.833 s WAV, TTS 4.062 s, STT 0.578 s | [Prior measured result](evidence/local-audio-check.json) |
| Earlier Alive sketch compile | 277,259 bytes flash / 22,300 bytes static RAM | [Prior build](evidence/alive-build.txt) |

Final checks from repository root:

```powershell
.\.venv\Scripts\python.exe -m pytest -v
.\.venv\Scripts\python.exe -m ruff check backend
.\.venv\Scripts\python.exe -m compileall -q backend
.\.venv\Scripts\python.exe -m pip check
```

Mocked inference verifies request construction and integration, not recognition accuracy or spoken voice quality. The earlier Piper/Whisper experiment used synthetic speech, not a recording from the pin. Real cloud services and OCR were not tested. ESP32 core 3.3.3 was not compiled; 3.3.12 is the actual build version.

## Implemented behavior

- Qwen receives actual JPEG bytes, current question and bounded history on every visual turn. llama3.2 remains the ordinary text model. Prompts require visible evidence, uncertainty for unreadable labels and no electrical measurement/safety claims from appearance.
- JPEG registration returns a unique image ID independently of inference. Explicit image/context IDs bind asynchronous voice and typed questions to snapshots; transcripts, answers and WAVs use existing job APIs.
- SQLite per-device sessions persist image references and recent successful turns. Default fixed expiry is five minutes; default history bound is six pairs. New image/clear resets history; expired/replaced contexts reject late answers. Ownership checks cover images, jobs and audio.
- Firmware long press/c registers; short press/v asks; follow-up v reuses explicit context. i synchronizes and x clears. SD streaming, raw recordings, WAV validation/playback and original pins remain. Pending retries retain original associations.
- Synthetic labelled JPEGs, direct model probe, HTTP conversation client, architecture/API/setup guides and V01–V10 procedures are delivered. See [source change inventory](MULTIMODAL_CHANGES.md).

## Local environment and remaining setup

Existing .venv, Whisper/Piper models and user settings were retained. Only the four requested vision variables were upserted in private backend/.env; other provider choices may still be mock, so select Whisper/Ollama/Piper for real use. The pre-extension backup is under ignored .backups; it contains private local settings and must remain private. No credentials were printed or added to examples.

Ollama needs `ollama pull qwen2.5vl:3b` and `ollama pull llama3.2:3b`; its CLI may require a fresh terminal or installation PATH repair. Configure firmware Wi-Fi/LAN URL/token, compile/upload to the actual COM port, then test serial controls before buttons. All physical V01–V10 tests remain pending, along with unexecuted portions of the original T01–T20 plan. Hardware successes described in the original brief remain user-reported evidence.

## Known limitations

1. Shared-token trusted-LAN HTTP: IDs enforce logical separation, but anyone knowing the token can impersonate an ID. TLS and independent credentials are future work. Use one backend process per data directory.
2. Vision quality, camera readability, microphone accuracy and MAX98357A playback need measured real-world tests. A camera cannot measure live electrical values, find hidden defects or certify safety. Record wrong guesses.
3. Native inference uses a thread; deadlines prevent late publication but cannot terminate a stuck native call. Restart if it never returns. Measure cold model latency and coordinate provider/job/firmware deadlines with context lifetime.
4. POST retry is not idempotent; lost acknowledgement may create another image/job. Known IDs and original context persist on SD; stale questions must be recorded again after recapture. Device raw files need manual archival/free-space management.
5. Clearing/expiry removes image eligibility, not all evidence immediately. Server originals follow retention (default 24 h); jobs retain exact JPEG snapshots. A crash can leave an orphan file requiring review. Back up evidence before cleanup.
6. Battery-only amplifier power, GPIO3 strapping, optional drivers, camera revision and acoustics need physical validation. Static build RAM is not peak runtime memory.
7. General desktop WAVs may need normalization to the canonical 44-byte-header, 16 kHz PCM16 mono device format. Firmware JPEG uploads cap at 2 MiB even if the server accepts more.

Next: real laptop recognition on known labels, then serial c → v → v and V01–V10 on the pin. Software completion does not establish physical acceptance.
