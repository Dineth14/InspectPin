#pragma once
// Copy to config.local.h and edit. Never commit real credentials.
#define IP_WIFI_SSID "Dineth’s iPhone 14"
#define IP_WIFI_PASSWORD "dineth18"
#define IP_SERVER_URL "http://172.20.10.4:5000"
#define IP_DEVICE_TOKEN "7deXICZ5eu_V0zKjsSj5xFcDTTdFFXqF"
// Leave empty to identify this board by its unique eFuse MAC.
#define IP_DEVICE_ID ""
#define IP_RECORD_SECONDS 5
#define IP_PLAYBACK_GAIN 1.00f
#define IP_DEBUG true
#define IP_CAMERA_ENABLED true
// Enable for a second momentary camera button: D5/GPIO6 to GND.
// Otherwise D2/GPIO3 retains short=voice, long=camera behavior.
#define IP_CAMERA_BUTTON_ENABLED true
#define IP_BATTERY_ENABLED false
#define IP_LIGHT_ENABLED false
#define IP_HAPTIC_ENABLED false
#define IP_BATTERY_CALIBRATION 1.0f
#define IP_LOW_BATTERY_VOLTS 3.4f
