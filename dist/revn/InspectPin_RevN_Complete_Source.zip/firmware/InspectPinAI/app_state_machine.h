#pragma once
#include "button_manager.h"
#include "api_client.h"
#include "command_types.h"
#include "operation_guard.h"
#include "state_model.h"
enum class AppState { BOOT, INITIALIZING, READY, RECORDING, VIDEO_RECORDING, SAVING, UPLOADING, WAITING_FOR_AI, DOWNLOADING, PLAYING, OFFLINE, RETRYING, ERROR, LOW_BATTERY };
class App {
 public: void begin(); void tick();
 private:
  AppState state_=AppState::BOOT;
  ButtonManager button_;
  OperationGuard operation_;
  StateController runtime_;
  String path_,job_,answerPath_;
  JobResult jobResult_;
  SessionContext context_;
  String captureImage_,captureContext_;
  uint32_t contextAt_=0;
  bool imagePending_=false;
  bool sdReady_=false;
  uint32_t lastPoll_=0,jobStart_=0,retryAt_=0,lastBattery_=0;
  unsigned attempts_=0;
  void state(AppState value);
  void fail(const String &error, bool offline=false);
  void capture(bool image);
  void retry();
  void syncContext(bool clear=false);
  void useContext(const SessionContext &context);
  bool idle() const;
  void handleCommand(const DeviceCommand &command);
  void updateRuntimeState(AppState value);
};
